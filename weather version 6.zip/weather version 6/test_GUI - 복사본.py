import tkinter as tk
from tkinter import ttk
from MYGUI import get_current_weather, analyse_weather, recommend_top, recommend_bottom
  # MYGUI에서 함수 가져오기

from LocationSelector import LocationSelector  # Frame 1에서 사용하는 클래스

class Frame2(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg="white")
        
        # UI 요소 정의
        self.temp_label = tk.Label(self, text="현재 기온: ---", font=("Arial", 14))
        self.temp_label.pack(pady=10)

        self.mintem_label = tk.Label(self, text="최저기온: ---", font=("Arial", 12))
        self.mintem_label.pack(pady=5)

        self.maxtem_label = tk.Label(self, text="최고기온: ---", font=("Arial", 12))
        self.maxtem_label.pack(pady=5)

        self.top_label = tk.Label(self, text="추천 상의: ---", font=("Arial", 12))
        self.top_label.pack(pady=5)

        self.bottom_label = tk.Label(self, text="추천 하의: ---", font=("Arial", 12))
        self.bottom_label.pack(pady=5)

        tk.Button(self, text="날씨 갱신", command=self.update_weather).pack(pady=10)
        tk.Button(self, text="더보기", command=self.open_more).pack(pady=10)

    def update_weather(self):
        """날씨 정보를 갱신하고 UI를 업데이트합니다."""
        temp, weather_status, min_temp, max_temp = get_current_weather("서울")
        if temp != "N/A":
            analysis, suggestion = analyse_weather(float(temp))
            top = recommend_top(float(temp))
            bottom = recommend_bottom(float(temp))

            self.temp_label.config(text=f"현재 기온: {temp}°C")
            self.mintem_label.config(text=f"최저기온: {min_temp}°C")
            self.maxtem_label.config(text=f"최고기온: {max_temp}°C")
            self.top_label.config(text=f"추천 상의: {top}")
            self.bottom_label.config(text=f"추천 하의: {bottom}")
        else:
            tk.messagebox.showerror("에러", "날씨 정보를 가져오지 못했습니다.")

    def open_more(self):
        """더보기 메뉴를 팝업으로 표시"""
        more_window = tk.Toplevel(self)
        more_window.title("더보기")
        more_window.geometry("600x400")

        tk.Label(more_window, text="더보기 메뉴", font=("Arial", 18, "bold")).pack(pady=10)

        # 더보기 메뉴 버튼들
        tk.Button(more_window, text="내 옷장 보기", command=self.show_wardrobe).pack(pady=10)
        tk.Button(more_window, text="옷 색 조합 추천", command=self.show_color_recommendations).pack(pady=10)
        tk.Button(more_window, text="옷 보관법", command=self.show_clothing_maintenance).pack(pady=10)
        tk.Button(more_window, text="옷 빨래법", command=self.show_clothing_care).pack(pady=10)
        tk.Button(more_window, text="날씨에 맞는 옷 입기", command=self.show_dressing_tips).pack(pady=10)

    def show_wardrobe(self):
        tk.messagebox.showinfo("내 옷장 보기", "상의: 코트, 니트, 셔츠\n하의: 청바지, 두꺼운 바지, 반바지\n")

    def show_color_recommendations(self):
        tk.messagebox.showinfo("옷 색 조합 추천", "위아래 깔맞춤은 기피하는 것이 좋습니다\n상:파란색+하:베이지색\n상:하얀색+하:파란색\n상:파란색+하:빨간색\n상:검은색+하:하얀색")

    def show_clothing_maintenance(self):
        tk.messagebox.showinfo("옷 보관법", "티셔츠: 개어서 보관\n청바지: 엉덩이 부분이 맞닿도록 접고 두번 개서 보관\n셔츠: 옷걸이에 걸어 보관\n:니트: 개서 보관\n코트: 옷걸이에 걸어 보관")

    def show_clothing_care(self):
        tk.messagebox.showinfo("옷 빨래법", "울: 드라이클리닝\n데님: 뒤집어서 세탁\n니트: 손빨래 혹은 뒤집어서 세탁\n코트: 드라이클리닝")

    def show_dressing_tips(self):
        tk.messagebox.showinfo("날씨에 맞는 옷 입기", "5도 이하: 패딩\n5~10도: 코트, 야상, 가디건\n10~15도: 자켓, 가디건, 청바지\n15도 이상: 셔츠, 반바지")

"""
class Frame3(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg="red")
        tk.Label(self, text="This is Frame 3", bg="red", fg="white", font=("Arial", 18)).pack(pady=20)
        
        # 옷장 추가/삭제 버튼
        tk.Button(self, text="내 옷장 추가/삭제", command=self.open_closet_manager).pack(pady=10)

    def open_closet_manager(self):
        #MYGUI의 옷장 관리 기능 호출
        try:
            open_cloth_manager()  # MYGUI.py의 함수 호출
        except Exception as e:
            tk.messagebox.showerror("오류", f"옷장 관리 기능을 열 수 없습니다: {e}")
"""



def show_frame(frame):
    """컨테이너에 새 프레임 표시"""
    for widget in container_frame.winfo_children():
        widget.pack_forget()
    frame.pack(fill=tk.BOTH, expand=True)

# 메인 창 생성
root = tk.Tk()
root.geometry("800x700")
root.title("날씨에 맞는 옷 추천 프로그램")

# 컨테이너 프레임
container_frame = tk.Frame(root, bg="white")
container_frame.pack(fill=tk.BOTH, expand=True, side=tk.LEFT)

# 버튼 패널
button_panel = tk.Frame(root, bg="lightgray")
button_panel.pack(fill=tk.Y, side=tk.RIGHT)

# 여러 프레임 정의
frame1 = LocationSelector(container_frame)  # Frame 1: 날씨랑 습도, 위치 정보
frame2 = Frame2(container_frame)  # Frame 2: 날씨에 맞는 옷 추천 프로그램 강민우 GUI 삽입


# 프레임 전환 버튼
tk.Button(button_panel, text="위치/날씨 정보", command=lambda: show_frame(frame1)).pack(fill=tk.X, padx=5, pady=5)
tk.Button(button_panel, text="날씨에 맞는 옷 추천", command=lambda: show_frame(frame2)).pack(fill=tk.X, padx=5, pady=5)

# 초기 프레임 표시
show_frame(frame1)

root.mainloop()
